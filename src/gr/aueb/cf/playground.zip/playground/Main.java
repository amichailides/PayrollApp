package gr.aueb.cf.playground;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) throws IOException {

        Path path = Paths.get("src/gr/aueb/cf/playground/employees.txt");
        /*
        List<Employee> employees = new ArrayList<>();

        Employee emp = new Employee("Mixos", "IT", BigDecimal.valueOf(200.50));
        Employee emp2 = new Employee("Matsablokos", "IT", BigDecimal.valueOf(23));

        employees.add(emp);
        employees.add(emp2);


        for (Employee e : employees){
            FileUtils.writeLine(path, e.toLine());
        }
        */


        List<Employee> fromFile = Employee.createEmployees(path);
        fromFile.forEach(System.out::println);

    }



}
